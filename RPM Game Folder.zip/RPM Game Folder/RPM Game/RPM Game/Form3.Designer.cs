﻿
namespace LotteryGame
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.Rock = new System.Windows.Forms.Button();
            this.Paper = new System.Windows.Forms.Button();
            this.Scissors = new System.Windows.Forms.Button();
            this.ComputerGuess = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Cpoint = new System.Windows.Forms.Label();
            this.Ppoint = new System.Windows.Forms.Label();
            this.ComputerPoint = new System.Windows.Forms.Label();
            this.PlayerPoint = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.PlayAgain = new System.Windows.Forms.Button();
            this.Rounds = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Rock
            // 
            this.Rock.BackgroundImage = global::LotteryGame.Properties.Resources.Rock;
            this.Rock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Rock.Location = new System.Drawing.Point(324, 394);
            this.Rock.Name = "Rock";
            this.Rock.Size = new System.Drawing.Size(251, 106);
            this.Rock.TabIndex = 3;
            this.Rock.Text = "Rock";
            this.Rock.UseVisualStyleBackColor = true;
            this.Rock.Click += new System.EventHandler(this.Rock_Click);
            // 
            // Paper
            // 
            this.Paper.BackgroundImage = global::LotteryGame.Properties.Resources.Paper;
            this.Paper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Paper.Location = new System.Drawing.Point(324, 282);
            this.Paper.Name = "Paper";
            this.Paper.Size = new System.Drawing.Size(251, 106);
            this.Paper.TabIndex = 2;
            this.Paper.Text = "Paper";
            this.Paper.UseVisualStyleBackColor = true;
            this.Paper.Click += new System.EventHandler(this.Paper_Click);
            // 
            // Scissors
            // 
            this.Scissors.BackgroundImage = global::LotteryGame.Properties.Resources.Scissors1;
            this.Scissors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Scissors.Location = new System.Drawing.Point(324, 170);
            this.Scissors.Name = "Scissors";
            this.Scissors.Size = new System.Drawing.Size(251, 106);
            this.Scissors.TabIndex = 1;
            this.Scissors.Text = "Scissors";
            this.Scissors.UseVisualStyleBackColor = true;
            this.Scissors.Click += new System.EventHandler(this.Scissors_Click);
            // 
            // ComputerGuess
            // 
            this.ComputerGuess.AutoSize = true;
            this.ComputerGuess.BackColor = System.Drawing.SystemColors.GrayText;
            this.ComputerGuess.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.ComputerGuess.Location = new System.Drawing.Point(325, 69);
            this.ComputerGuess.Name = "ComputerGuess";
            this.ComputerGuess.Size = new System.Drawing.Size(0, 44);
            this.ComputerGuess.TabIndex = 10;
            this.ComputerGuess.Click += new System.EventHandler(this.ComputerGuess_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.label4.Location = new System.Drawing.Point(238, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(448, 44);
            this.label4.TabIndex = 11;
            this.label4.Text = "Click on the images below to pick your choice ";
            // 
            // Cpoint
            // 
            this.Cpoint.AutoSize = true;
            this.Cpoint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Cpoint.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.Cpoint.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Cpoint.Location = new System.Drawing.Point(113, 169);
            this.Cpoint.Name = "Cpoint";
            this.Cpoint.Size = new System.Drawing.Size(175, 44);
            this.Cpoint.TabIndex = 12;
            this.Cpoint.Text = "Computer Points";
            this.Cpoint.Click += new System.EventHandler(this.Cpoint_Click);
            // 
            // Ppoint
            // 
            this.Ppoint.AutoSize = true;
            this.Ppoint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Ppoint.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.Ppoint.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Ppoint.Location = new System.Drawing.Point(630, 169);
            this.Ppoint.Name = "Ppoint";
            this.Ppoint.Size = new System.Drawing.Size(129, 44);
            this.Ppoint.TabIndex = 13;
            this.Ppoint.Text = "Your Points";
            this.Ppoint.Click += new System.EventHandler(this.Ppoint_Click);
            // 
            // ComputerPoint
            // 
            this.ComputerPoint.AutoSize = true;
            this.ComputerPoint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ComputerPoint.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.ComputerPoint.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.ComputerPoint.Location = new System.Drawing.Point(169, 231);
            this.ComputerPoint.Name = "ComputerPoint";
            this.ComputerPoint.Size = new System.Drawing.Size(32, 44);
            this.ComputerPoint.TabIndex = 14;
            this.ComputerPoint.Text = "0";
            // 
            // PlayerPoint
            // 
            this.PlayerPoint.AutoSize = true;
            this.PlayerPoint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.PlayerPoint.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.PlayerPoint.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.PlayerPoint.Location = new System.Drawing.Point(675, 231);
            this.PlayerPoint.Name = "PlayerPoint";
            this.PlayerPoint.Size = new System.Drawing.Size(32, 44);
            this.PlayerPoint.TabIndex = 15;
            this.PlayerPoint.Text = "0";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button4.Location = new System.Drawing.Point(638, 458);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(134, 42);
            this.button4.TabIndex = 16;
            this.button4.Text = "Quit ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.result.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.result.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.result.Location = new System.Drawing.Point(372, 231);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(0, 44);
            this.result.TabIndex = 17;
            this.result.Visible = false;
            this.result.Click += new System.EventHandler(this.result_Click);
            // 
            // PlayAgain
            // 
            this.PlayAgain.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.PlayAgain.Location = new System.Drawing.Point(389, 426);
            this.PlayAgain.Name = "PlayAgain";
            this.PlayAgain.Size = new System.Drawing.Size(134, 42);
            this.PlayAgain.TabIndex = 18;
            this.PlayAgain.Text = "Play Again";
            this.PlayAgain.UseVisualStyleBackColor = false;
            this.PlayAgain.Visible = false;
            this.PlayAgain.Click += new System.EventHandler(this.PlayAgain_Click);
            // 
            // Rounds
            // 
            this.Rounds.AutoSize = true;
            this.Rounds.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Rounds.Font = new System.Drawing.Font("Niagara Engraved", 25F);
            this.Rounds.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Rounds.Location = new System.Drawing.Point(630, 304);
            this.Rounds.Name = "Rounds";
            this.Rounds.Size = new System.Drawing.Size(89, 44);
            this.Rounds.TabIndex = 19;
            this.Rounds.Text = "Round: ";
            this.Rounds.Click += new System.EventHandler(this.Rounds_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BackgroundImage = global::LotteryGame.Properties.Resources.Welcome;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(878, 530);
            this.Controls.Add(this.Rounds);
            this.Controls.Add(this.PlayAgain);
            this.Controls.Add(this.result);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.PlayerPoint);
            this.Controls.Add(this.ComputerPoint);
            this.Controls.Add(this.Ppoint);
            this.Controls.Add(this.Cpoint);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ComputerGuess);
            this.Controls.Add(this.Rock);
            this.Controls.Add(this.Paper);
            this.Controls.Add(this.Scissors);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.Text = "RPMGame";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Scissors;
        private System.Windows.Forms.Button Paper;
        private System.Windows.Forms.Button Rock;
        private System.Windows.Forms.Label ComputerGuess;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Cpoint;
        private System.Windows.Forms.Label Ppoint;
        private System.Windows.Forms.Label ComputerPoint;
        private System.Windows.Forms.Label PlayerPoint;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.Button PlayAgain;
        private System.Windows.Forms.Label Rounds;
    }
}