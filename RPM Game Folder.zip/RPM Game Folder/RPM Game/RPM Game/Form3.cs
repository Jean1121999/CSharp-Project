﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LotteryGame
{
    public partial class Form3 : Form
    {
        Random ran = new Random();
        public double PlayerPoints = 0, ComputerPoints = 0;
        public int rounds = 0; 
         
        


        public Form3()
        {
            InitializeComponent();
        }

       
        private void Scissors_Click(object sender, EventArgs e)
        {
            rounds += 1; //counts the rounds 
            Rounds.Text = "Rounds: " + rounds; //Displays the round number 
            PlayAgain.Show();
            int random = ran.Next(0,3);
            String[] computer = { "Rock", "Paper", "Scissors" };
            String computerGuess = "" + computer[random]; 
            Scissors.Text = "Scissors";
        
            ComputerGuess.Text = "Computer guessed " + computerGuess;
            ComputerGuess.Show();

            if (Scissors.Text != computerGuess & computerGuess == "Paper")
            {
                
                PlayerPoints += 1;
                result.Show();
                result.Text = "You won!"; 
                
                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide(); 
            }
            else if(Scissors.Text == computerGuess)
            {
                PlayerPoints += 0.5;
                ComputerPoints += 0.5;
                result.Show();
                result.Text = "Tie Game!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
            else if (Scissors.Text != computerGuess & computerGuess == "Rock")
            {
                this.ComputerPoints += 1; //Adding 1 point 
                this.result.Show();
                result.Text = "Computer Won!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
                

            PlayerPoint.Text = "" + this.PlayerPoints;
            ComputerPoint.Text = "" + this.ComputerPoints;
            if (PlayerPoints < ComputerPoints)
            {
                Cpoint.BackColor = Color.Green;
                Ppoint.BackColor = Color.Red; 
            }
            else if (PlayerPoints == ComputerPoints)
            {
                Cpoint.BackColor = Color.Blue;
                Ppoint.BackColor = Color.Blue;
            }
            else
            {
                Cpoint.BackColor = Color.Red;
                Ppoint.BackColor = Color.Green;
            }
                



        }

        private void ComputerGuess_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            Form2 form2 = new Form2();
            form1.Close();
            form2.Close(); 
           
        }

        private void Paper_Click(object sender, EventArgs e)
        {
            rounds += 1; //counts the rounds
            Rounds.Text = "Rounds: " + rounds; //Displays the round number 
            PlayAgain.Show();
            int random = ran.Next(0, 3);
            String[] computer = { "Rock", "Paper", "Scissors" };
            String computerGuess = "" + computer[random];
            Paper.Text = "Paper";
            ComputerGuess.Text = "Computer guessed " + computerGuess;
            ComputerGuess.Show();

            if (Paper.Text != computerGuess & computerGuess == "Scissors")
            {
                ComputerPoints += 1;
                this.result.Show();
                result.Text = "Computer Win!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
            else if (Paper.Text == computerGuess)
            {
                PlayerPoints += 0.5;
                ComputerPoints += 0.5;
                this.result.Show();
                result.Text = "Tie game!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();

            }
            else
            {
                PlayerPoints += 1;
                result.Show();
                result.Text = "Player Won!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
               
                

            PlayerPoint.Text = "" + this.PlayerPoints;
            ComputerPoint.Text = "" + this.ComputerPoints;
            if (PlayerPoints < ComputerPoints)
            {
                Cpoint.BackColor = Color.Green;
                Ppoint.BackColor = Color.Red;
            }
            else if (PlayerPoints == ComputerPoints)
            {
                Cpoint.BackColor = Color.Blue;
                Ppoint.BackColor = Color.Blue;
            }
            else
            {
                Cpoint.BackColor = Color.Red;
                Ppoint.BackColor = Color.Green;
            }



        }

        private void result_Click(object sender, EventArgs e)
        {

        }

        private void Ppoint_Click(object sender, EventArgs e)
        {
            Ppoint.Text = "" + PlayerPoints;
            if (PlayerPoints > ComputerPoints)
            {
                Ppoint.BackColor = Color.Green;
            }
            else if (PlayerPoints == ComputerPoints)
            {
                Ppoint.BackColor = Color.Blue;
            }
            else
                Ppoint.BackColor = Color.Red; 
        }

        private void Cpoint_Click(object sender, EventArgs e)
        {
            Cpoint.Text = "" + ComputerPoints;
        }

        private void PlayAgain_Click(object sender, EventArgs e)
        {
            PlayAgain.Hide();
            result.Hide(); 
            this.Scissors.Show();
            this.Rock.Show();
            this.Paper.Show();
            ComputerGuess.Hide();

        }

        private void Rounds_Click(object sender, EventArgs e)
        {

        }

        private void Rock_Click(object sender, EventArgs e)
        {
            rounds += 1; //counts the rounds
            Rounds.Text = "Rounds: " + rounds; //Displays the round number 
            PlayAgain.Show(); 
            int random = ran.Next(0, 3);
            String[] computer = { "Rock", "Paper", "Scissors" };
            String computerGuess = "" + computer[random];
            Rock.Text = "Rock";

            ComputerGuess.Text = "Computer guessed " + computerGuess;
            ComputerGuess.Show(); 

            if (Rock.Text != computerGuess & computerGuess == "Scissors")
            {
                PlayerPoints += 1;
                this.result.Show();
                result.Text = "You Won!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
            else if (Rock.Text == computerGuess)
            {
                PlayerPoints += 0.5;
                this.ComputerPoints += 0.5;
                this.result.Show();
                result.Text = "Tie game!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();
            }
            else
            {
                ComputerPoints += 1;
                this.result.Show();
                result.Text = "Computer Won!";

                this.Scissors.Hide();
                this.Rock.Hide();
                this.Paper.Hide();

            }

            PlayerPoint.Text = "" + this.PlayerPoints;
            ComputerPoint.Text = "" + this.ComputerPoints;

            if (PlayerPoints < ComputerPoints)
            {
                Cpoint.BackColor = Color.Green;
                Ppoint.BackColor = Color.Red;
            }
            else if (PlayerPoints == ComputerPoints)
            {
                Cpoint.BackColor = Color.Blue;
                Ppoint.BackColor = Color.Blue;
            }
            else
            {
                Cpoint.BackColor = Color.Red;
                Ppoint.BackColor = Color.Green;
            }

        }
    }
}
